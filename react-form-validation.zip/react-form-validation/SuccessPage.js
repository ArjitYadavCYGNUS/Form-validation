
import React from "react";
import { useLocation, useNavigate } from "react-router-dom";

const SuccessPage = () => {
  const { state } = useLocation();
  const navigate = useNavigate();

  if (!state) {
    return <p>No data submitted. <button onClick={() => navigate("/")}>Go Back</button></p>;
  }

  return (
    <div className="success-container">
      <h2>Submission Successful!</h2>
      <ul>
        {Object.entries(state).map(([key, value]) => (
          key !== "showPassword" && (
            <li key={key}>
              <strong>{key}:</strong> {value}
            </li>
          )
        ))}
      </ul>
      <button onClick={() => navigate("/")}>Back to Form</button>
    </div>
  );
};

export default SuccessPage;
