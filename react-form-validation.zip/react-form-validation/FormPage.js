
import React, { useState } from "react";
import { useNavigate } from "react-router-dom";
import "./App.css";

const FormPage = () => {
  const navigate = useNavigate();

  const [formData, setFormData] = useState({
    firstName: "",
    lastName: "",
    username: "",
    email: "",
    password: "",
    showPassword: false,
    phoneCode: "+91",
    phoneNumber: "",
    country: "",
    city: "",
    pan: "",
    aadhar: "",
  });

  const [errors, setErrors] = useState({});

  const validate = () => {
    const newErrors = {};

    if (!formData.firstName.trim()) newErrors.firstName = "Required";
    if (!formData.lastName.trim()) newErrors.lastName = "Required";
    if (!formData.username.trim()) newErrors.username = "Required";
    if (!formData.email.match(/^[^\s@]+@[^\s@]+\.[^\s@]+$/))
      newErrors.email = "Invalid email";
    if (formData.password.length < 6)
      newErrors.password = "Minimum 6 characters required";
    if (!formData.phoneNumber.match(/^\d{10}$/))
      newErrors.phoneNumber = "10 digit number required";
    if (!formData.country) newErrors.country = "Select a country";
    if (!formData.city) newErrors.city = "Select a city";
    if (!formData.pan.match(/^[A-Z]{5}[0-9]{4}[A-Z]$/))
      newErrors.pan = "Invalid PAN format";
    if (!formData.aadhar.match(/^\d{12}$/))
      newErrors.aadhar = "12 digit Aadhar required";

    setErrors(newErrors);
    return Object.keys(newErrors).length === 0;
  };

  const isFormValid = () => {
    return validate();
  };

  const handleChange = (e) => {
    const { name, value, type, checked } = e.target;
    setFormData((prev) => ({
      ...prev,
      [name]: type === "checkbox" ? checked : value,
    }));
  };

  const handleSubmit = (e) => {
    e.preventDefault();
    if (isFormValid()) {
      navigate("/success", { state: formData });
    }
  };

  const citiesByCountry = {
    India: ["Delhi", "Mumbai", "Bangalore"],
    USA: ["New York", "Los Angeles", "Chicago"],
    UK: ["London", "Manchester", "Liverpool"],
  };

  return (
    <form onSubmit={handleSubmit} className="form-container">
      <h2>User Registration</h2>

      {[
        ["First Name", "firstName"],
        ["Last Name", "lastName"],
        ["Username", "username"],
        ["Email", "email"],
        ["PAN No.", "pan"],
        ["Aadhar No.", "aadhar"],
      ].map(([label, name]) => (
        <div key={name}>
          <label>{label}</label>
          <input
            type="text"
            name={name}
            value={formData[name]}
            onChange={handleChange}
          />
          {errors[name] && <span className="error">{errors[name]}</span>}
        </div>
      ))}

      <div>
        <label>Password</label>
        <input
          type={formData.showPassword ? "text" : "password"}
          name="password"
          value={formData.password}
          onChange={handleChange}
        />
        <label>
          <input
            type="checkbox"
            name="showPassword"
            checked={formData.showPassword}
            onChange={handleChange}
          />
          Show Password
        </label>
        {errors.password && <span className="error">{errors.password}</span>}
      </div>

      <div>
        <label>Phone No.</label>
        <select name="phoneCode" value={formData.phoneCode} onChange={handleChange}>
          <option value="+91">+91 (India)</option>
          <option value="+1">+1 (USA)</option>
          <option value="+44">+44 (UK)</option>
        </select>
        <input
          type="text"
          name="phoneNumber"
          value={formData.phoneNumber}
          onChange={handleChange}
        />
        {errors.phoneNumber && <span className="error">{errors.phoneNumber}</span>}
      </div>

      <div>
        <label>Country</label>
        <select name="country" value={formData.country} onChange={handleChange}>
          <option value="">--Select--</option>
          {Object.keys(citiesByCountry).map((country) => (
            <option key={country}>{country}</option>
          ))}
        </select>
        {errors.country && <span className="error">{errors.country}</span>}
      </div>

      <div>
        <label>City</label>
        <select name="city" value={formData.city} onChange={handleChange}>
          <option value="">--Select--</option>
          {(citiesByCountry[formData.country] || []).map((city) => (
            <option key={city}>{city}</option>
          ))}
        </select>
        {errors.city && <span className="error">{errors.city}</span>}
      </div>

      <button type="submit" disabled={!isFormValid()}>
        Submit
      </button>
    </form>
  );
};

export default FormPage;
